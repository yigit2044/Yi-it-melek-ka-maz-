# Yiğit ❤️ Melek — özel sevgili sitesi

Bu proje mobil uyumlu romantik bir başlangıç sitesi ve Cloudflare Pages Functions üzerinden ortak şifre kapısı içerir.

## Önemli: ilk sürümün sınırları
- Ortak şifre, `functions/_middleware.js` ile sunucu tarafında kontrol edilir; şifreyi HTML dosyasına koymayın.
- Albümde seçilen fotoğraf/video dosyaları şimdilik yalnızca seçildiği tarayıcıda önizlenir; siteye yüklenmez ve Melek'in telefonunda görünmez.
- Mektuplar tarayıcının yerel depolamasına kaydedilir; farklı telefonlar arasında paylaşılmaz.
- Ortak albüm ve ortak mektup arşivi için sonraki aşamada bir veritabanı ve dosya depolaması eklemek gerekir.

## Ücretsiz yayınlama: Cloudflare Pages

1. Bir bilgisayardan GitHub hesabı açın veya mevcut hesabınızı kullanın.
2. Bu ZIP dosyasını açın ve içindeki `index.html` ile `functions` klasörünü yeni bir GitHub deposuna yükleyin.
3. Cloudflare hesabı açın ve **Workers & Pages → Create → Pages → Connect to Git** yoluyla GitHub deposunu bağlayın.
4. Framework preset: **None**. Build command boş bırakın. Build output directory olarak `/` veya `.` seçin (arayüzde hangisi kabul edilirse).
5. Pages projesi oluşturulduktan sonra **Settings → Variables and Secrets** bölümünde `SITE_PASSWORD` adlı bir secret ekleyin. İkinizin de kullanacağı tahmin edilmesi zor bir şifre seçin. Şifreyi kod dosyalarına yazmayın.
6. Projeyi yeniden dağıtın. Cloudflare size `*.pages.dev` biçiminde bir bağlantı verir.
7. Linki Melek'e gönderin; ikiniz de aynı şifreyle giriş yapabilirsiniz.

Cloudflare arayüzünün isimleri zamanla değişebilir. `functions/_middleware.js` dosyası Pages Functions özelliği sayesinde site isteklerine şifre kapısı uygular.

## Telefonda test
Yayınlanan bağlantıyı açın, şifre ekranının geldiğini kontrol edin, doğru şifreyle giriş yapın. Gizli sekmede yeniden açıp şifre ekranının geldiğini doğrulayın.

## Güvenlik notu
Paylaşılan link tek başına gizlilik sağlamaz; güvenlik ortak şifreye dayanır. Şifreyi sadece güvendiğiniz kişiyle paylaşın. Fotoğraf/video veya mektupları çok özel içerik olarak kullanacaksanız, sonraki aşamada ortak bulut depolama ve yetkilendirme eklemeden önce bu ilk sürümün yerel kayıt sınırlamalarını unutmayın.
