const encoder = new TextEncoder();

async function tokenFor(secret) {
  const key = await crypto.subtle.importKey(
    "raw", encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode("yigit-melek-site-session-v1"));
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

function loginPage(message = "") {
  return new Response(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#fff0f5"><title>Yiğit ❤️ Melek</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(145deg,#fff4f8,#ffdce9);font-family:system-ui;color:#79334f;padding:18px}.card{width:min(390px,100%);background:#ffffffdf;border:1px solid white;border-radius:25px;padding:28px;box-shadow:0 15px 50px #b94c751c;text-align:center}h1{font-size:2rem;margin:0 0 8px}p{color:#9b6b7f}input,button{font:inherit;width:100%;padding:13px;border-radius:13px;box-sizing:border-box}input{border:1px solid #efbfd0;margin:10px 0;background:white}button{border:0;background:#e85d91;color:white;font-weight:700;cursor:pointer}.error{color:#b42355;font-size:.9rem}</style></head><body><main class="card"><div style="font-size:2.3rem">💗</div><h1>Yiğit ❤️ Melek</h1><p>Burası sadece ikimizin küçük dünyası. İçeri girmek için ortak şifremizi yaz. 💌</p>${message ? `<div class="error">${message}</div>` : ""}<form method="POST" action="/login"><input type="password" name="password" placeholder="Ortak şifre" required autocomplete="current-password"><button type="submit">Aşk dünyamıza gir ❤️</button></form></main></body></html>`, {
    status: 200, headers: { "content-type": "text/html; charset=UTF-8", "cache-control": "no-store" }
  });
}

export async function onRequest(context) {
  const { request, env, next } = context;
  if (!env.SITE_PASSWORD) {
    return new Response("Kurulum gerekli: Cloudflare Pages ayarlarında SITE_PASSWORD adlı bir secret tanımlayın. README dosyasına bakın.", { status: 503 });
  }
  const url = new URL(request.url);
  const expected = await tokenFor(env.SITE_PASSWORD);

  if (url.pathname === "/login" && request.method === "POST") {
    const form = await request.formData();
    const submitted = form.get("password");
    if (typeof submitted !== "string" || submitted !== env.SITE_PASSWORD) {
      return loginPage("Şifre doğru değil, tekrar dene.");
    }
    return new Response(null, {
      status: 303,
      headers: {
        "location": "/",
        "set-cookie": `ym_access=${expected}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=2592000`,
        "cache-control": "no-store"
      }
    });
  }

  if (url.pathname === "/logout") {
    return new Response(null, { status: 303, headers: { "location": "/", "set-cookie": "ym_access=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0", "cache-control": "no-store" } });
  }

  const cookies = request.headers.get("Cookie") || "";
  const match = cookies.match(/(?:^|;\\s*)ym_access=([^;]+)/);
  if (match && match[1] === expected) return next();
  return loginPage();
}
